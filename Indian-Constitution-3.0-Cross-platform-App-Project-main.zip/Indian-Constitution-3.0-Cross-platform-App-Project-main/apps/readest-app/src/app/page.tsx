import { redirectToLibrary } from '@/utils/nav';

const HomePage = () => {
  redirectToLibrary();
};

export default HomePage;

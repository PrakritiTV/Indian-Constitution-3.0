export const BOOK_FILE_NOT_FOUND_ERROR = 'Book file not found';

import XCTest
@testable import SafariAuthPlugin

final class SafariAuthPluginTests: XCTestCase {
    func testExample() throws {
        let plugin = SafariAuthPlugin()
    }
}

# Tauri Plugin safari-auth

A description of this package.

# Tauri Plugin safari-auth

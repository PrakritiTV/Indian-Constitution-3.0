package com.plugin.safari_auth

import android.util.Log

class Example {
    fun pong(value: String): String {
        Log.i("Pong", value)
        return value
    }
}
